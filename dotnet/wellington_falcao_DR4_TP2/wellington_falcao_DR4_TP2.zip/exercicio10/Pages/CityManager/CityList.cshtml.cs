using Microsoft.AspNetCore.Mvc.RazorPages;

namespace exercicio10.Pages.CityManager
{
    public class CityListModel : PageModel
    {
        public List<string> Cities { get; set; }

        public void OnGet()
        {
            Cities = new List<string> { "Rio de Janeiro", "S�o Paulo", "Bras�lia", "Belo Horizonte" };
        }
    }
}
