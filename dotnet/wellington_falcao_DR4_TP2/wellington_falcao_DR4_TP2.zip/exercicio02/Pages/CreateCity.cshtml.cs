using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CityManager
{
    public class CreateCityModel : PageModel
    {
        public string SubmittedCity { get; set; }

        // Handler agora recebe o par�metro diretamente
        public void OnPost(string cityName)
        {
            if (!string.IsNullOrWhiteSpace(cityName))
            {
                SubmittedCity = cityName;
            }
        }
    }
}
